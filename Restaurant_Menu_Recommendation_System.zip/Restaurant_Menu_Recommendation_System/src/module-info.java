/**
 * 
 */
/**
 * 
 */
module Restaurant_Menu_Recommendation_System {
	requires java.sql;
}